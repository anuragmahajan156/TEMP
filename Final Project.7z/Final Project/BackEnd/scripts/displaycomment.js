const displaycomment=(bid)=>{
    $.ajax({
        type: "GET",
        contentType: "application/json",
        url: "http://localhost:3000/users",
        dataType: "json",
        success: (users) => {

                var userMap=new Map();
                for(let i=0;i<users.length;i++)
                {
                    userMap.set(`${users[i].id}`,`${users[i].name}`);
                }

              /*  userMap.forEach(function(value, key) {
                    console.log(key + " = " + value);
                })  */

                $.ajax({
                    type: "GET",
                    contentType: "application/json",
                    url: `http://localhost:3000/blogs?id=${bid}`,
                    dataType: "json",
                    success: (blog) => {
                        if (blog != null) {
                            var {
                                comments
                            } = blog[0];
                            let temp="<table>";
                            for(let i=0;i<comments.length;i++)
                            {
                                temp+=`<table class="showComment">
                                            <tr><td>Name:${userMap.get(comments[i].userid)}</td></tr>
                                            <tr><td>Comment:${comments[i].text}</td></tr><br>
                                        </table>
                                      `
                            }
                            temp+="</table>";
                            document.getElementById("allcomments").innerHTML=temp;
                        }
                    }
                });


        }
    });


}







