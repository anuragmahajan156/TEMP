
 var editor;
 var flag=false;
 var display=()=>{
    console.log("here");
    var isLogin=sessionStorage.getItem("userid");
    if(isLogin!=null)
    {
       //document.getElementById("login").style.visibility="none";
       //document.getElementById("signup").style.visibility="none";

       document.getElementById("login").style.display="none";
       document.getElementById("signup").style.display="none";

    }
    else{

       // document.getElementById("createblog").style.visibility="none";
       // document.getElementById("logout").style.visibility="none";

        document.getElementById("createblog").style.display="none";
        document.getElementById("logout").style.display="none";

    }

}

var onloadtexteditor=()=>{

display();

    ClassicEditor
.create( document.querySelector( '#editor' ) )
.then( newEditor => {
    editor = newEditor;
} )
.catch( error => {
    console.error( error );
} );

}




var handleOnClickforBlog=(event)=>{
    event.preventDefault();
    try{
        var name = document.getElementById('image').files.item(0).name;
    }catch(e){
        var name="none";
    }
    if(name!="none"){
        flag=true;
    }
    else{
        flag=false;
    }
// Assuming there is a <button id="submit">Submit</button> in your application.
    /*document.querySelector( '.submit-btn' ).addEventListener( 'click', () => {
    const editorData = editor.getData();
    console.log(editorData);
    })*/






    const editorData = editor.getData();
    console.log(editorData);
    let editortext = editorData.replace(/<[^>]+>/g, '');
    //console.log(plainText);
    var userid=sessionStorage.getItem("userid");
    var blog={
        userid:userid,
	    category:document.getElementById("category").value,
	    title:document.getElementById("txttitle").value,
	    imgpath:"../BackEnd/images/"+name,
        text:editortext,
	    timestamp:new Date(),
	    likes:0,
	    comments:[],
        flag:flag,
        likeStatus:[]
    }


        console.log(blog);
            $.ajax({
                type: 'POST',
                contentType: 'application/json',
                url: "http://localhost:3000/blogs",
                data:JSON.stringify(blog),
                dataType: "json",
                success: function(resultData) { alert("Save Complete")
                                                 console.log(resultData);}

            })

}

